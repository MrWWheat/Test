# 746FlashSim
A modified version of FlashSim for CMU 18-/15-746: Storage Systems course project

Note:
Only file students should edit is src/myFTL.cpp. This is the only file submitted
to autolab. Any local changes to other files, though might be beneficial during
debugging/development, will have no effect on autolab.

Note:
Set macro CONFIG_TWOPROC to 0 for development/design. Makes gdb debugging
easier.
