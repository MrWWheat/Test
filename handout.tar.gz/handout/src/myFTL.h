#ifndef __MYFTL_H__
#define __MYFTL_H__

#include "common.h"

FTLBase<TEST_PAGE_TYPE>* CreateMyFTL(const ConfBase *conf);

#endif /* __MYFTL_H__ */
